package com.example.sharedpreferences;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText namee,emaill;
    Button savee;
    SharedPreferences sp;

    private static final String spName="mypref";
    private static final String keyName="n";
    private static final String keyEmail="e";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        namee=findViewById(R.id.name);
        emaill=findViewById(R.id.email);
        savee=findViewById(R.id.save);

        sp=getSharedPreferences(spName,MODE_PRIVATE);
        //When open activity first check Shared preferences data is available or not

        String n=sp.getString(keyName,null);
        if (n!=null)
        {
            //If data is available, directly call the homeActivity
            Intent intent=new Intent(MainActivity.this,HomeActivity.class);
            startActivity(intent);
        }

        savee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //When a button is clicked, put the data on shared preferences
                SharedPreferences.Editor editor=sp.edit();
                editor.putString(keyName,namee.getText().toString());
                editor.putString(keyEmail,emaill.getText().toString());
                editor.apply();

                Intent intent=new Intent(MainActivity.this,HomeActivity.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this, "Login Success", Toast.LENGTH_SHORT).show();



            }
        });




    }
}
package com.example.calculs2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button Badd,Bsub,Bmul,Bdiv;
    EditText ETn1,ETn2;
    TextView TVans;
    int n1,n2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Badd = findViewById(R.id.btnAdd);
        Bsub = findViewById(R.id.btnSub);
        Bmul = findViewById(R.id.btnMul);
        Bdiv = findViewById(R.id.btnDiv);
        ETn1=findViewById(R.id.num1);
        ETn2=findViewById(R.id.num2);
        TVans=findViewById(R.id.ans);

        Badd.setOnClickListener(this);
        Bsub.setOnClickListener(this);
        Bmul.setOnClickListener(this);
        Bdiv.setOnClickListener(this);


    }




    @Override
    public void onClick(View view) {
        n1 = Integer.parseInt(ETn1.getText().toString());
        n2 = Integer.parseInt(ETn2.getText().toString());
        float result = 0; // Initialize a variable to store the result

        int id = view.getId();
        if (id == R.id.btnAdd) {
            result = n1 + n2;
        } else if (id == R.id.btnSub) {
            result = n1 - n2;
        } else if (id == R.id.btnMul) {
            result = n1 * n2;
        } else if (id == R.id.btnDiv) {
            result = (float)n1 / (float)n2;
        }

        TVans.setText("Answer=" + result);
    }

}